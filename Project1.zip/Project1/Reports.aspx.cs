﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Text;
using System.IO;

namespace Project1
{
    public partial class Reports : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString);
                conn.Open();
                SqlCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Select * From users ";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
       
 
                GridView2.DataSource = dt;
                GridView2.DataBind();


                conn.Close();

            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try { 
            DataTable dt = new DataTable();
                DataTable dtCol = new DataTable();
                string colName = "";
                string dType = "";
                string dsType = ""; 
                string tbls = "";
                string filecs = "";
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString);
                conn.Open();
                SqlCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from INFORMATION_SCHEMA.TABLES where TABLE_TYPE='BASE TABLE'";
                cmd.ExecuteNonQuery();
                

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count-1; i++)
                    {
                        // tbls = tbls + dt.Rows[i]["TABLE_NAME"].ToString();
                        cmd.CommandText = "select * from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME='"+ dt.Rows[i]["TABLE_NAME"].ToString() + "'";
                        cmd.ExecuteNonQuery(); 
                        da.Fill(dtCol);
                        if (dtCol.Rows.Count > 0)
                        {
                            filecs = " using System;\r\n";
                            filecs = filecs + " namespace ClassLibrary2\r\n";
                            filecs = filecs + " {\r\n"; 
                            for (int x = 0; x < dtCol.Rows.Count-1; x++)
                            {
                                if (dtCol.Rows[x]["DATA_TYPE"].ToString() == "int")
                                {
                                    filecs = filecs + "  public int "+ dtCol.Rows[x]["COLUMN_NAME"].ToString()+ "  { get; set; }\r\n"; 
                                                     }
                                else if(dtCol.Rows[x]["DATA_TYPE"].ToString() == "varchar")
                                {
                                    filecs = filecs + "  public string " + dtCol.Rows[x]["COLUMN_NAME"].ToString() + "  { get; set; }\r\n";
                                }
                                else if (dtCol.Rows[x]["DATA_TYPE"].ToString() == "date")
                                {
                                    filecs = filecs + "  public DateTime " + dtCol.Rows[x]["COLUMN_NAME"].ToString() + "  { get; set; }\r\n";
                                }
                            }

                            filecs = filecs + " }";
                            Savefile(dt.Rows[i]["TABLE_NAME"].ToString(), filecs);
                        }
                    }
                    Label1.Text = tbls;
                }
            }
                catch(Exception ex)
            {
                Label1.Text = ex.Message;
            }
        }

        
         void Savefile(string filenm,string dtData)
        {
            try
            {
              
                    System.IO.File.WriteAllText(@"F:\modelss\test1\"+ filenm+".cs", dtData);
                
            }
            catch(Exception ex)
            {

            }
        }

    }
}